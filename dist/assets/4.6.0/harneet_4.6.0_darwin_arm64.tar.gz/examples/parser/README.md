# Parser Tests

This directory contains test files for parser functionality, token consumption patterns, and expression boundary handling.

## Test Files

### Working Tests (Pass Successfully)

- **`test_token_consumption.ha`** - Tests parseExpressionList/parseExpression interaction patterns
- **`test_newline_consumption.ha`** - Tests NEWLINE token handling in various contexts
- **`test_semicolon_simple.ha`** - Tests simple semicolon statement terminators
- **`test_expression_boundaries.ha`** - Tests expression parsing boundary detection
- **`test_boundaries_fixed.ha`** - Tests expression boundaries with proper imports
- **`test_comparison_parsing.ha`** - Tests comparison operators in different contexts
- **`test_simple_multiline.ha`** - Tests simple expressions without line breaks

### Known Limitation Tests

- **`test_operator_boundaries.ha`** - Demonstrates multi-line operator expression parsing limitations
  - ⚠️ This test will cause a panic due to incomplete AST when operators are split across lines
  - Shows areas for future improvement in multi-line expression support

## Usage

Run all parser tests:
```bash
just test_parser
```

Run individual tests:
```bash
./harneet examples/parser/test_newline_consumption.ha
```

## Purpose

These tests serve to:
1. Verify parser token consumption patterns work correctly
2. Test the interaction between `parseExpressionList()` and `parseExpression()`
3. Document current parser capabilities and limitations
4. Provide regression testing for parser improvements
5. Demonstrate where multi-line expression support could be added in the future