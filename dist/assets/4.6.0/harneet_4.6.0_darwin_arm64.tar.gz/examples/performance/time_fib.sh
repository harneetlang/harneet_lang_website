#!/bin/bash

echo "Timing Harneet Fibonacci..."
{ time ./harneet examples/performance/fibonacci.ha; } 2>&1

echo ""
echo "Timing Python Fibonacci..."
{ time python3 examples/performance/fibonacci.py; } 2>&1


echo "==============================================="

