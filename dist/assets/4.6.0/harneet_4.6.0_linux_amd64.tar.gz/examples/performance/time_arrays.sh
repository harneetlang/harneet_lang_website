#!/bin/bash

echo "Timing Harneet Array Operations..."
{ time ./harneet examples/performance/array_operations.ha; } 2>&1

echo ""

echo "Timing Python Array Operations..."
{ time python3 examples/performance/array_operations.py; } 2>&1

echo "==============================================="