# Harneet vs Python Performance Benchmarks

This directory contains comprehensive performance benchmarks comparing Harneet and Python across various computational tasks.

## Available Benchmarks

### 1. Random Number Generation
- **Files**: `random.ha`, `random.py`, `time_test.sh`
- **Test**: Linear congruential generator with 10 iterations
- **Result**: Python ~0.36s, Harneet ~0.37s (comparable)

### 2. Fibonacci Calculation
- **Files**: `fibonacci.ha`, `fibonacci.py`, `time_fib.sh`
- **Test**: Recursive fibonacci(20)
- **Result**: Python ~0.05s, Harneet ~95s (Python 1900x faster)

### 3. String Manipulation
- **Files**: `string_manipulation.ha`, `string_manipulation.py`, `time_string.sh`
- **Test**: String concatenation and manipulation operations
- **Result**: Python ~0.04s, Harneet ~0.71s (Python 18x faster)

### 4. File I/O Operations
- **Files**: `file_io.ha`, `file_io.py`, `time_io.sh`
- **Test**: File write and read operations
- **Result**: Python ~0.04s, Harneet ~0.06s (Python slightly faster)

### 5. Array Operations
- **Files**: `array_operations.ha`, `array_operations.py`, `time_arrays.sh`
- **Test**: Array sum operations with large datasets
- **Result**: Python ~0.07s, Harneet ~0.28s (Python 4x faster)

### 6. Map/Dictionary Operations
- **Files**: `map_operations.ha`, `map_operations.py`, `time_maps.sh`
- **Test**: Map creation, lookup, and iteration operations
- **Result**: Python ~0.03s, Harneet ~0.31s (Python 10x faster)

### 7. Factorial Calculations
- **Files**: `recursive_factorial.ha`, `recursive_factorial.py`, `time_factorial.sh`
- **Test**: Recursive and iterative factorial calculations
- **Result**: Python ~0.06s, Harneet ~0.32s (Python 5x faster)

### 8. Nested Loops & Matrix Operations
- **Files**: `nested_loops.ha`, `nested_loops.py`, `time_nested.sh`
- **Test**: Triple nested loops and matrix-like calculations
- **Result**: Python ~0.06s, Harneet ~124s (Python 2000x faster)

## Running the Benchmarks

### Run All Performance Tests
```bash
just test_performance
```

### Run Individual Tests
```bash
# Random number generation
bash examples/performance/time_test.sh

# Fibonacci calculation
bash examples/performance/time_fib.sh

# String manipulation
bash examples/performance/time_string.sh

# File I/O
bash examples/performance/time_io.sh

# Array operations
bash examples/performance/time_arrays.sh

# Map operations
bash examples/performance/time_maps.sh

# Factorial calculations
bash examples/performance/time_factorial.sh

# Nested loops
bash examples/performance/time_nested.sh
```

### View Performance Summary
```bash
bash examples/performance/performance_summary.sh
```

## Key Findings

### Performance Comparison Summary
- **Winner**: Python wins in all benchmarks
- **Closest Competition**: Random number generation (nearly tied)
- **Biggest Gaps**: Recursive operations and nested loops (1000-2000x slower)

### Harneet Performance Characteristics
- **Strengths**: Simple I/O operations, basic arithmetic
- **Weaknesses**: Recursive calls, nested loops, complex data operations
- **Bottlenecks**: Interpreter overhead, lack of optimization

### Optimization Opportunities for Harneet
1. **JIT Compilation**: Could dramatically improve performance
2. **Tail Call Optimization**: Would help recursive operations
3. **Loop Optimization**: Critical for nested loop performance
4. **Data Structure Optimization**: Improve array/map operations
5. **Bytecode Compilation**: Reduce interpretation overhead

## Technical Notes

### Harneet Syntax Requirements
- Functions must have explicit return types: `function name() int { ... }`
- Arrays use bracket notation: `[1, 2, 3]`
- Maps use brace notation: `{"key": "value"}`
- Loops use `for i in range(n)` syntax

### Test Environment
- **OS**: macOS (darwin)
- **Shell**: zsh
- **Timing**: Uses `time` command for accurate measurements
- **Iterations**: Multiple runs for consistency

## Future Improvements

### Planned Benchmarks
- Memory usage comparison
- Concurrent/parallel operations
- Network I/O performance
- JSON parsing/serialization
- Regular expression performance

### Optimization Tracking
- Add performance regression testing to CI/CD
- Track performance improvements over time
- Benchmark against other interpreted languages
- Profile memory usage and garbage collection