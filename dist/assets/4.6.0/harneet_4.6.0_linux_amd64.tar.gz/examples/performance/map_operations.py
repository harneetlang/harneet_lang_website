def map_operations():
    m = {}
    
    # Insert operations
    for i in range(1000):
        key = f"key_{i}"
        m[key] = i * 2
    
    # Lookup operations
    total = 0
    for i in range(1000):
        key = f"key_{i}"
        if key in m:
            total += m[key]
    
    # Delete operations
    for i in range(500):
        key = f"key_{i}"
        if key in m:
            del m[key]
    
    print(f"Final sum: {total}, Remaining keys: {len(m)}")

if __name__ == "__main__":
    map_operations()