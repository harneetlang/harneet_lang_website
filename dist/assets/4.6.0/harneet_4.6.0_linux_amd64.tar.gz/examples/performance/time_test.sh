#!/bin/bash

echo "Timing Harneet script..."
{ time for i in {1..10}; do ./harneet examples/performance/random.ha > /dev/null; done; } 2>&1

echo ""

echo "Timing Python script..."
{ time for i in {1..10}; do python3 examples/performance/random.py > /dev/null; done; } 2>&1


echo "==============================================="
