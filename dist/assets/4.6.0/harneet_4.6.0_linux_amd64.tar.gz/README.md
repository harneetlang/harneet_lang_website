# Harneet Programming Language - Beginner's Guide
 
Welcome to Harneet! This guide will teach you everything you need to know about the Harneet programming language, designed especially for newcomers to programming. Inspired by golang and some python!

## 🌟 What is Harneet?

Harneet is a simple, easy-to-learn programming language that's perfect for beginners. It has clean syntax inspired by Go and includes basic programming concepts like variables, math, and decision-making.

Think of Harneet as a friendly way to learn programming fundamentals before moving on to more complex languages.

Please see the [Language Specification](LANGUAGE_SPEC.md), for detailed language specifications.

Please note that Harneet is still being actively worked on and features that you would normally see in other programming languages are still not present in Harneet.Definitely not to be used in Production!!

## 🚀 Getting Started

### Installation & Running Programs

1. **Build Harneet** (one-time setup):
   ```bash
   just build
   # This creates the 'harneet' program
   ```

2. **Try the interactive mode** (REPL):
   ```bash
   just repl
   # Type commands and see results immediately
   ```

3. **Run a program file**:
   ```bash
   ./harneet examples/hello.ha
   # Runs code from a file (uses .ha extension)
   ```

## 📝 Your First Program

Let's start with the classic "Hello, World!" program:

```harneet
import fmt
fmt.Println("Hello, World!")
```

**What this does:**
- `import fmt` loads the formatting module (needed for printing)
- `fmt.Println()` is a command that prints text to the screen
- The text inside quotes `"Hello, World!"` is what gets printed
- Every statement in Harneet can be on its own line

**Try it yourself:**
1. Save this code in a file called `hello.ha`
2. Run it with: `./harneet hello.ha`

## 🔢 Working with Numbers

Harneet can do math! Here are the basics:

```harneet
import fmt
fmt.Println(5 + 3)    // Prints: 8
fmt.Println(10 - 4)   // Prints: 6  
fmt.Println(6 * 7)    // Prints: 42
fmt.Println(15 / 3)   // Prints: 5
fmt.Println(7 </ 2)   // Prints: 3 (floor division)
fmt.Println(-7 </ 2)  // Prints: -4 (rounds toward negative infinity)
fmt.Println(17 % 5)   // Prints: 2 (remainder)
```

**Math Operators:**
- `+` addition
- `-` subtraction  
- `*` multiplication
- `/` division
- `</` floor division (rounds toward negative infinity)
- `%` remainder (modulo)

## 📦 Variables - Storing Information

Variables are like labeled boxes where you can store information. Harneet supports two ways to create variables:

**Method 1: Explicit Types (tell Harneet the type):**
```harneet
var age int = 25
var name string = "Alice"
```

**Method 2: Type Inference (let Harneet figure out the type):**
```harneet  
var age = 25        // Harneet knows this is an int
var name = "Alice"  // Harneet knows this is a string
```

Both work exactly the same! Choose whichever feels more comfortable.

```harneet
fmt.Println("Name:", name)
fmt.Println("Age:", age)
```

**How variables work:**
- `var` tells Harneet you're creating a variable
- `age` is the variable name (you choose this)
- `int` or automatic type detection means it stores whole numbers
- `= 25` puts the value 25 into the variable

**Variable Types:**
- `int` - whole numbers (1, 42, -5)
- `string` - text in quotes ("hello", "Harneet")

### 📝 Multiline Strings

Harneet supports multiline strings using backticks (`` ` ``), perfect for formatted text like SQL queries or HTML:

```harneet
var greeting = `Hello there!
Welcome to Harneet programming.
This text spans multiple lines
and preserves all formatting.`

fmt.Println(greeting)
```

**Multiline String Features:**
- Use backticks (`` ` ``) instead of regular quotes
- Preserves line breaks and indentation exactly as written
- No need to escape quotes or backslashes
- Perfect for SQL, HTML, JSON, and configuration data

**Example with SQL:**
```harneet
var createTable = `
    CREATE TABLE users (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE
    )
`
fmt.Println(createTable)
```

### Changing Variables

You can change what's stored in a variable:

```harneet
var score int = 100
fmt.Println("Score:", score)  // Prints: Score: 100

score = 150
fmt.Println("New score:", score)  // Prints: New score: 150
```

### Quick Variable Creation

There's a shortcut for creating variables:

```harneet
x := 42        // Same as: var x int = 42
message := "Hi there"  // Same as: var message string = "Hi there"
```

## 🧮 Math with Variables

You can do math with variables just like with numbers:

```harneet
var a int = 10
var b int = 5

fmt.Println("a + b =", a + b)    // Prints: a + b = 15
fmt.Println("a * b =", a * b)    // Prints: a * b = 50

var total int = a + b + 20
fmt.Println("Total:", total)     // Prints: Total: 35
```

## 🤔 Making Decisions with `if`

Sometimes your program needs to make decisions based on conditions:

```harneet
var temperature int = 75

if temperature > 70 {
    fmt.Println("It's warm outside!")
}
```

**How `if` works:**
- `if` starts the decision
- `temperature > 70` is the condition (true or false)
- Code inside `{ }` runs only if the condition is true

### Comparison Operators

These help you compare values:

```harneet
var x int = 10
var y int = 20

if x < y {
    fmt.Println("x is smaller than y")
}

if x == 10 {
    fmt.Println("x equals 10")
}

if y != 15 {
    fmt.Println("y is not 15")
}
```

**Comparison operators:**
- `<` less than
- `>` greater than
- `<=` less than or equal
- `>=` greater than or equal  
- `==` equals
- `!=` not equals

## 🔄 Repeating with Loops

Loops let you repeat code multiple times:

```harneet
for i := 0; i < 5; i = i + 1 {
    fmt.Println("Count:", i)
}
```

**This prints:**
```
Count: 0
Count: 1
Count: 2
Count: 3
Count: 4
```

**How the loop works:**
- `i := 0` creates a counter starting at 0
- `i < 5` continues while i is less than 5
- `i = i + 1` adds 1 to i after each round
- Code in `{ }` runs each time

### Simple Loops

You can also make simpler loops:

```harneet
var count int = 0
for count < 3 {
    fmt.Println("Hello!")
    count = count + 1
}
```

## 🔗 Logical Operators

You can combine conditions using logical operators:

```harneet
var age int = 20
var hasLicense int = 1  // 1 means true, 0 means false

if age >= 16 and hasLicense == 1 {
    fmt.Println("Can drive!")
}

var isWeekend int = 1
var isHoliday int = 0

if isWeekend == 1 or isHoliday == 1 {
    fmt.Println("No work today!")
}
```

**Logical operators:**
- `and` - both conditions must be true
- `or` - at least one condition must be true  
- `not` - flips true to false, false to true

## 📋 Complete Example Programs

### Example 1: Age Calculator

```harneet
var birthYear int = 2000
var currentYear int = 2024
var age int = currentYear - birthYear

fmt.Println("Birth year:", birthYear)
fmt.Println("Current year:", currentYear)
fmt.Println("Your age is:", age)

if age >= 18 {
    fmt.Println("You are an adult!")
}
```

### Example 2: Simple Calculator

```harneet
var num1 int = 15
var num2 int = 4

fmt.Println("Number 1:", num1)
fmt.Println("Number 2:", num2)
fmt.Println("Sum:", num1 + num2)
fmt.Println("Difference:", num1 - num2)
fmt.Println("Product:", num1 * num2)
fmt.Println("Division:", num1 / num2)
fmt.Println("Remainder:", num1 % num2)
```

### Example 3: Grade Checker

```harneet
var score int = 85

fmt.Println("Your score:", score)

if score >= 90 {
    fmt.Println("Grade: A - Excellent!")
}

if score >= 80 and score < 90 {
    fmt.Println("Grade: B - Good job!")
}

if score >= 70 and score < 80 {
    fmt.Println("Grade: C - Not bad!")
}

if score < 70 {
    fmt.Println("Grade: F - Study more!")
}
```

### Example 4: Working with Multiline Strings

```harneet
import fmt
import strings

// Create a multiline string for a simple HTML page
var htmlPage = `<!DOCTYPE html>
<html>
<head>
    <title>My First Page</title>
</head>
<body>
    <h1>Welcome to Harneet!</h1>
    <p>This HTML was created using a multiline string.</p>
    <p>No escaping needed for "quotes" or 'apostrophes'!</p>
</body>
</html>`

fmt.Println("HTML Page:")
fmt.Println(htmlPage)

// Work with the multiline string using string functions
var pageLength, _ = strings.Len(htmlPage)
fmt.Printf("\nHTML page length: %d characters\n", pageLength)

var hasTitle, _ = strings.Contains(htmlPage, "<title>")
fmt.Printf("Contains title tag: %t\n", hasTitle)
```

## 📚 Built-in Modules (Advanced Features)

As you get more comfortable with Harneet, you can explore its built-in modules for more powerful features:

```harneet
import fmt      // Printing and formatting
import math     // Mathematical functions
import strings  // Text manipulation
import datetime // Date and time operations
import os       // Operating system features
import file     // File operations
import log      // Logging messages
import assert   // Runtime assertions for testing and debugging
```

These modules provide advanced functionality when you're ready to explore them!

## 🚫 Things Harneet Doesn't Have (Yet)

Harneet is designed for learning, so it doesn't have some advanced features: (we are still working on them)
- Complex data types

This focused approach makes it perfect for learning programming fundamentals!

## 🔧 Tips for Success

1. **Start small** - Begin with simple programs and add complexity gradually
2. **Experiment** - Try changing values and see what happens
3. **Use the REPL** - Test small pieces of code interactively
4. **Read error messages** - They tell you what went wrong
5. **Practice daily** - Even 10 minutes a day helps!

## 🐛 Common Beginner Mistakes

### Mistake 1: Missing quotes for text
```harneet
// Wrong:
fmt.Println(Hello)

// Right:
fmt.Println("Hello")
```

### Mistake 2: Using = instead of ==
```harneet
// Wrong (assigns value):
if x = 5 {

// Right (compares):
if x == 5 {
```

### Mistake 3: Trying to use a single variable for functions that return multiple values
```harneet
// Wrong (shows helpful error message):
var result = math.Abs(-42)

// Right (handle both result and error):
var result, err = math.Abs(-42)
if err != None {
    fmt.Println("Error:", err)
} else {
    fmt.Println("Result:", result)
}
```

## 🎯 Next Steps

Once you're comfortable with Harneet, you might want to learn:
1. **Go** - Harneet's syntax is similar to Go
2. **Python** - Great for beginners, very popular
3. **JavaScript** - For web development
4. **C** - To understand how computers work

## 🔗 Getting Help

- **Run examples**: `just test` runs all example programs
- **Try interactive mode**: `just repl` for experimenting
- **Check the documentation**: Read `CLAUDE.md` for technical details
- **Practice**: The `examples/` folder has more programs to study

## 🏷️ Automatic Releases

The project uses conventional commit messages to automatically create releases:

- `feat:` → Creates a **minor** version bump (e.g., 1.0.0 → 1.1.0)
- `fix:` → Creates a **patch** version bump (e.g., 1.0.0 → 1.0.1)  
- `BREAKING CHANGE:` → Creates a **major** version bump (e.g., 1.0.0 → 2.0.0)

**Example commit messages:**
```bash
git commit -m "feat: add new string manipulation functions"
git commit -m "fix: resolve parser error with semicolons"
git commit -m "feat!: redesign error handling system

BREAKING CHANGE: all functions now return (result, error) tuples"
```

When you push commits with these prefixes to the main branch, GitHub Actions will automatically:
- Determine the next version number
- Create a git tag
- Build release binaries for multiple platforms
- Create a GitHub release with download links

## 🎉 Congratulations!

You now know the basics of the Harneet programming language! Remember:
- Programming is like learning a new language - it takes practice
- Every expert was once a beginner
- The most important thing is to keep experimenting and having fun!

Happy coding! 🚀
