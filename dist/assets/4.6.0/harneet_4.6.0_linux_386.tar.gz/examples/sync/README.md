# Sync Module Examples

This directory contains comprehensive examples demonstrating the usage of Harneet's `sync` module for concurrent programming. The sync module provides mutex and read-write mutex primitives for protecting shared data in concurrent applications.

## Overview

The sync module examples are organized into five main categories:

1. **Basic Mutex Usage** (`basic_mutex_test.ha`)
2. **Concurrency Integration** (`concurrency_integration_test.ha`)
3. **Mutex Patterns** (`mutex_patterns_test.ha`)
4. **Read-Write Mutex** (`rwmutex_test.ha`)
5. **Shared Data Protection** (`shared_data_test.ha`)

## Running the Examples

To run any example, use the Harneet interpreter:

```bash
./harneet examples/sync/basic_mutex_test.ha
./harneet examples/sync/concurrency_integration_test.ha
./harneet examples/sync/mutex_patterns_test.ha
./harneet examples/sync/rwmutex_test.ha
./harneet examples/sync/shared_data_test.ha
```

## Example Files

### 1. Basic Mutex Usage (`basic_mutex_test.ha`)

**Purpose**: Demonstrates fundamental mutex operations and error handling patterns.

**Key Features**:
- Mutex creation with `sync.NewMutex()`
- Basic Lock/Unlock operations
- TryLock functionality for non-blocking operations
- Comprehensive error handling patterns
- Shared counter protection example

**What You'll Learn**:
- How to create and use mutexes
- Proper error handling with mutex operations
- The difference between blocking and non-blocking lock operations
- How to protect shared data from race conditions

**Example Output**:
```
=== Basic Mutex Usage Examples ===

--- Test 1: Basic Mutex Operations ---
✓ Created new mutex successfully
✓ Acquired lock successfully
✓ Released lock successfully

--- Test 2: TryLock Operations ---
✓ TryLock succeeded on unlocked mutex
✓ TryLock correctly failed on locked mutex
✓ TryLock succeeded after unlock
```

### 2. Concurrency Integration (`concurrency_integration_test.ha`)

**Purpose**: Shows how mutexes integrate with Harneet's `do`/`await` concurrency model.

**Key Features**:
- Using mutexes with `do`/`await` tasks
- Multiple concurrent tasks sharing mutexes
- Producer-consumer patterns with concurrency
- Task coordination using mutexes
- RWMutex with concurrent readers

**What You'll Learn**:
- How to use mutexes in concurrent scenarios
- Coordination between multiple tasks
- Producer-consumer pattern implementation
- Integration with Harneet's concurrency primitives

**Example Output**:
```
=== Concurrency Integration Examples ===

--- Test 1: Basic do/await with Mutex ---
Starting counter: 0
Task1: 0 -> 1
Task2: 1 -> 2
Task1: 2 -> 3
...
Final counter: 5
✓ do/await with mutex integration working correctly
```

### 3. Mutex Patterns (`mutex_patterns_test.ha`)

**Purpose**: Demonstrates advanced patterns and best practices for mutex usage.

**Key Features**:
- Lock ordering to prevent deadlocks
- Try-lock patterns for timeout handling
- Resource pool pattern implementation
- Reader-writer priority patterns
- Error handling and recovery strategies
- Conditional synchronization

**What You'll Learn**:
- How to prevent deadlocks through proper lock ordering
- Implementing timeout and retry logic with try-locks
- Managing limited resources safely
- Advanced coordination patterns
- Best practices for robust concurrent programming

**Example Output**:
```
=== Comprehensive Mutex Patterns Examples ===

--- Test 1: Lock Ordering (Deadlock Prevention) ---
Task1 starting read-modify operation
Task1 acquired resource A
Task1 acquired resource B
Task1 performing read-modify with both resources
...
✓ Lock ordering pattern prevents deadlocks
```

### 4. Read-Write Mutex (`rwmutex_test.ha`)

**Purpose**: Demonstrates RWMutex operations and performance considerations.

**Key Features**:
- RWMutex creation with `sync.NewRWMutex()`
- Concurrent read operations
- Exclusive write operations
- Read-write interaction patterns
- TryLock operations for RWMutex
- Performance comparison with regular mutex

**What You'll Learn**:
- When to use RWMutex vs regular mutex
- How multiple readers can access data simultaneously
- How write operations block all other access
- Performance benefits for read-heavy workloads

**Example Output**:
```
=== Read-Write Mutex Examples ===

--- Test 2: Concurrent Read Access ---
Acquiring multiple read locks simultaneously:
✓ Reader 1 acquired read lock
✓ Reader 2 acquired read lock
✓ Reader 3 acquired read lock
All readers can access data simultaneously
```

### 5. Shared Data Protection (`shared_data_test.ha`)

**Purpose**: Shows how to protect various data structures with mutexes.

**Key Features**:
- Array protection with concurrent append/read operations
- Map protection with concurrent set/get/iterate operations
- Struct field protection with safe updates
- Producer-consumer buffer implementation
- Complex data structure operations (arrays of maps)

**What You'll Learn**:
- How to protect different data types safely
- Implementing producer-consumer patterns
- Managing complex nested data structures
- Thread-safe operations on shared state

**Example Output**:
```
=== Shared Data Protection Examples ===

--- Test 1: Array Protection ---
Appender1 appended 'A1' (array size: 1)
Appender2 appended 'B1' (array size: 2)
Appender1 appended 'A2' (array size: 3)
...
Final array size: 5
✓ Array protection working correctly
```

## Performance Considerations

### When to Use Regular Mutex vs RWMutex

**Use Regular Mutex When**:
- Write operations are frequent
- Operations are short and simple
- Memory usage is a concern
- Workload is balanced between reads and writes

**Use RWMutex When**:
- Read operations significantly outnumber writes
- Read operations are expensive or time-consuming
- Multiple concurrent readers would benefit performance
- Data is read-heavy (e.g., configuration, lookup tables)

### Performance Tips

1. **Keep Critical Sections Short**: Minimize the time locks are held
2. **Avoid Nested Locking**: Use consistent lock ordering to prevent deadlocks
3. **Use Try-Lock for Timeouts**: Implement timeout logic with non-blocking operations
4. **Consider Lock-Free Alternatives**: For simple operations like counters

## Best Practices

### 1. Lock Ordering
Always acquire multiple locks in the same order across all tasks:

```harneet
// Good: Consistent ordering
var _, _ = mutexA.Lock()
var _, _ = mutexB.Lock()
// ... use resources ...
var _, _ = mutexB.Unlock()
var _, _ = mutexA.Unlock()
```

### 2. Error Handling
Always check errors from mutex operations:

```harneet
var success, err = mutex.Lock()
if err != None {
    fmt.Println("Lock failed:", err)
    return
}
// ... critical section ...
var _, unlockErr = mutex.Unlock()
if unlockErr != None {
    fmt.Println("Unlock failed:", unlockErr)
}
```

### 3. Resource Management
Use try-lock patterns for resource pools:

```harneet
var acquired, err = resourceMutex.TryLock()
if err != None {
    return "error: " + err.Error()
}
if not acquired {
    return "resource busy, try again later"
}
// ... use resource ...
var _, _ = resourceMutex.Unlock()
```

### 4. Timeout Handling
Implement retry logic with try-locks:

```harneet
var attempts = 0
var maxAttempts = 3
for attempts < maxAttempts {
    var acquired, err = mutex.TryLock()
    if err == None and acquired {
        // Got the lock, proceed
        break
    }
    attempts = attempts + 1
}
```

## Common Pitfalls and Solutions

### 1. Deadlocks
**Problem**: Tasks waiting for each other's locks indefinitely.
**Solution**: Use consistent lock ordering and avoid circular dependencies.

### 2. Race Conditions
**Problem**: Unsynchronized access to shared data.
**Solution**: Protect all shared data access with appropriate mutexes.

### 3. Lock Contention
**Problem**: Too many tasks competing for the same lock.
**Solution**: Use RWMutex for read-heavy workloads or redesign data structures.

### 4. Forgotten Unlocks
**Problem**: Locks not released, causing deadlocks.
**Solution**: Always pair Lock() with Unlock(), handle errors properly.

### 5. Double Locking
**Problem**: Attempting to lock an already held mutex.
**Solution**: Use try-lock patterns or careful state management.

## Troubleshooting Guide

### Debugging Mutex Issues

1. **Use the DebugMutex Function**:
```harneet
var debugInfo = sync.DebugMutex(mutex)
fmt.Println(debugInfo)
```

2. **Check Lock State**:
```harneet
var acquired, err = mutex.TryLock()
if acquired {
    fmt.Println("Mutex is available")
    var _, _ = mutex.Unlock()
} else {
    fmt.Println("Mutex is currently locked")
}
```

3. **Monitor Lock Duration**:
Track how long locks are held to identify bottlenecks.

### Common Error Messages

- `"mutex is already locked"`: Attempting to lock an already locked mutex
- `"mutex is not locked"`: Attempting to unlock an unlocked mutex
- `"mutex not owned by current task"`: Attempting to unlock from wrong task
- `"rwmutex has active read locks"`: Attempting write lock with active readers
- `"rwmutex is write locked"`: Attempting read lock with active writer

## Integration with Other Harneet Features

### With Error Handling
```harneet
var result, err = someOperation()
if err != None {
    var _, _ = mutex.Unlock()  // Ensure cleanup
    return err
}
```

### With Pattern Matching
```harneet
match operationType {
    case "read" => {
        var _, _ = rwmutex.RLock()
        // ... read operation ...
        var _, _ = rwmutex.RUnlock()
    }
    case "write" => {
        var _, _ = rwmutex.Lock()
        // ... write operation ...
        var _, _ = rwmutex.Unlock()
    }
}
```

### With Blank Identifier
```harneet
var _, err = mutex.Lock()  // Ignore success result, check error
if err != None {
    return err
}
```

## Conclusion

The sync module examples demonstrate comprehensive usage patterns for concurrent programming in Harneet. They show how to:

- Protect shared data safely
- Integrate with Harneet's concurrency model
- Implement common patterns like producer-consumer
- Handle errors gracefully
- Optimize performance with appropriate mutex types

These examples serve as both learning resources and reference implementations for building robust concurrent applications in Harneet.