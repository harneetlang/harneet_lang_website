# Tail Call Optimization Examples

This directory contains example programs demonstrating tail call optimization (TCO) in the Harneet programming language. These examples showcase how TCO enables efficient recursive programming patterns and prevents stack overflow errors in deeply recursive functions.

## What is Tail Call Optimization?

Tail call optimization is a compiler/interpreter optimization that eliminates the overhead of function calls when a function call is the last operation in a function. Instead of creating new stack frames, the interpreter reuses the current stack frame, which:

- Prevents stack overflow in deep recursion
- Improves performance by eliminating call overhead
- Enables functional programming patterns
- Maintains the same program behavior while using constant stack space

## Examples Overview

### 1. `factorial_recursive.ha` - Basic Tail Recursion

**Purpose**: Demonstrates the difference between regular recursion and tail recursion using factorial computation.

**Key Concepts**:
- Regular recursion vs. tail recursion
- Stack frame reuse
- Performance comparison
- Deep recursion without stack overflow

**What you'll learn**:
- How to identify tail calls vs. non-tail calls
- Why `n * factorial(n-1)` is NOT tail recursive
- Why `return factorial_tail(n-1, n*acc)` IS tail recursive
- Performance benefits of tail call optimization

### 2. `fibonacci_tail.ha` - Performance Optimization

**Purpose**: Shows dramatic performance improvements from tail recursion, comparing exponential vs. linear time complexity.

**Key Concepts**:
- Exponential vs. linear time complexity
- Accumulator pattern in tail recursion
- Performance analysis
- Very deep recursion capabilities

**What you'll learn**:
- How tail recursion can change algorithm complexity
- The accumulator technique for tail recursion
- Why regular recursive Fibonacci is inefficient
- How TCO enables practical recursive algorithms

### 3. `mutual_recursion.ha` - Cross-Function Optimization

**Purpose**: Demonstrates tail call optimization working across function boundaries with mutual recursion patterns.

**Key Concepts**:
- Mutual recursion between multiple functions
- State machine implementation
- Complex recursive patterns
- Parser/evaluator mutual recursion

**What you'll learn**:
- How TCO works between different functions
- State machine patterns using mutual recursion
- Complex mathematical sequences with mutual recursion
- Practical applications in parsing and evaluation

## Running the Examples

To run any of these examples, use the Harneet interpreter:

```bash
# Run the factorial example
./harneet examples/tail_call_optimization/factorial_recursive.ha

# Run the Fibonacci example
./harneet examples/tail_call_optimization/fibonacci_tail.ha

# Run the mutual recursion example
./harneet examples/tail_call_optimization/mutual_recursion.ha
```

## Understanding Tail Calls

### What Makes a Call "Tail"?

A function call is in "tail position" when:

1. **It's the last operation** in the function
2. **Its result is returned directly** without modification
3. **No operations occur** after the call returns

### Examples of Tail Calls:

```harneet
// ✅ TAIL CALL - result returned directly
func countdown(n) {
    if (n <= 0) return "Done!"
    return countdown(n - 1)  // This is a tail call
}

// ✅ TAIL CALL - in conditional, both branches are tail calls
func factorial_tail(n, acc) {
    if (n <= 1) {
        return acc           // Base case
    }
    return factorial_tail(n - 1, n * acc)  // Tail call
}
```

### Examples of Non-Tail Calls:

```harneet
// ❌ NOT TAIL CALL - multiplication happens after recursive call
func factorial_regular(n) {
    if (n <= 1) return 1
    return n * factorial_regular(n - 1)  // NOT tail call
}

// ❌ NOT TAIL CALL - addition happens after recursive call
func sum_to_n(n) {
    if (n <= 0) return 0
    return n + sum_to_n(n - 1)  // NOT tail call
}
```

## Performance Characteristics

| Algorithm Type | Time Complexity | Space Complexity | Max Input Size |
|---------------|----------------|------------------|----------------|
| Regular Recursive Factorial | O(n) | O(n) | ~1,000 |
| Tail Recursive Factorial | O(n) | O(1) | Unlimited* |
| Regular Recursive Fibonacci | O(2^n) | O(n) | ~40 |
| Tail Recursive Fibonacci | O(n) | O(1) | Unlimited* |
| Mutual Recursion (Even/Odd) | O(n) | O(1) | Unlimited* |

*Limited only by computation time and integer overflow, not stack space.

## Best Practices

### 1. Use Accumulators for Tail Recursion

Transform non-tail recursive functions using accumulator parameters:

```harneet
// Non-tail recursive
func sum(n) {
    if (n <= 0) return 0
    return n + sum(n - 1)
}

// Tail recursive with accumulator
func sum_tail(n, acc) {
    if (n <= 0) return acc
    return sum_tail(n - 1, acc + n)
}

func sum(n) {
    return sum_tail(n, 0)
}
```

### 2. Identify Tail Call Opportunities

Look for these patterns that can be optimized:
- Direct recursive calls as return statements
- Conditional expressions where all branches are tail calls
- State machines with function transitions
- Iterative processes expressed recursively

### 3. Understand Limitations

Tail call optimization cannot be applied when:
- Defer statements are present in the function
- The function returns multiple values
- Operations occur after the recursive call
- The call is not in tail position

## Educational Value

These examples demonstrate:

1. **Algorithmic Thinking**: How to transform algorithms for tail recursion
2. **Performance Analysis**: Understanding time and space complexity
3. **Functional Programming**: Recursive problem-solving techniques
4. **Language Features**: How interpreters optimize code execution
5. **Practical Applications**: Real-world uses of recursive patterns

## Further Reading

- [Tail Call Optimization Design Document](../../.kiro/specs/tail-call-optimization/design.md)
- [TCO Requirements Specification](../../.kiro/specs/tail-call-optimization/requirements.md)
- [Implementation Tasks](../../.kiro/specs/tail-call-optimization/tasks.md)

## Contributing

When adding new tail call optimization examples:

1. Include clear comments explaining the optimization
2. Compare with non-optimized versions when relevant
3. Demonstrate practical benefits (performance, stack safety)
4. Add educational explanations of the concepts
5. Test with both small and large inputs
6. Document any limitations or edge cases