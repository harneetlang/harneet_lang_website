import time

def random_lcg(seed):
    a = 1664525
    c = 1013904223
    m = 4294967296  # 2^32
    return (a * seed + c) % m

if __name__ == "__main__":
    seed = int(time.time() * 1_000_000_000)
    random_number = random_lcg(seed)
    print(random_number)
