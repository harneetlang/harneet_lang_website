#!/bin/bash

echo "Timing Harneet Map Operations..."
{ time ./harneet examples/performance/map_operations.ha; } 2>&1

echo ""

echo "Timing Python Map Operations..."
{ time python3 examples/performance/map_operations.py; } 2>&1

echo "==============================================="