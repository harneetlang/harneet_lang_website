if __name__ == "__main__":
    filename = "test.txt" # we need to delete this file, otherwise Github CI complains about Jira in a dirty state
    content = "Hello, World!"
    
    with open(filename, "w") as f:
        f.write(content)
        
    with open(filename, "r") as f:
        read_content = f.read()
        
    print(read_content)
