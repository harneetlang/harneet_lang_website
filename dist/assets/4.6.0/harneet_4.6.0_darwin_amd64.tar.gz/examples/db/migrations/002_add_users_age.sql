-- Migration: Add age column to users
-- Version: 2
-- Name: add_users_age_column

-- UP
ALTER TABLE users ADD COLUMN age INTEGER;

-- DOWN
ALTER TABLE users DROP COLUMN age;
