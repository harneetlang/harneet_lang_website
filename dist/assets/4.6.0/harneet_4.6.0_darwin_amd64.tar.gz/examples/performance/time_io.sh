#!/bin/bash

echo "Timing Harneet File I/O..."
{ time ./harneet examples/performance/file_io.ha; } 2>&1

echo ""

echo "Timing Python File I/O..."
{ time python3 examples/performance/file_io.py; } 2>&1

echo "==============================================="

