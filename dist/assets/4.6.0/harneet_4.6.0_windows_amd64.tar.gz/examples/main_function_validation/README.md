# Main Function Validation Examples

This directory contains examples demonstrating valid and invalid main function patterns in Harneet.

## Directory Structure

- `valid_patterns/` - Examples of correct main function usage
- `invalid_patterns/` - Examples that will cause compilation errors
- `multi_package/` - Examples of multi-package projects with proper main function organization

## Running Examples

### Valid Examples
```bash
# Single main function
harneet examples/main_function_validation/valid_patterns/single_main.ha

# Multi-file package with single main
harneet examples/main_function_validation/valid_patterns/multi_file_single_main/

# Library package (no main function)
# This would be imported by other packages, not run directly
```

### Invalid Examples
```bash
# These will produce compilation errors:
harneet examples/main_function_validation/invalid_patterns/multiple_main_same_package/

# Expected error:
# Error: Multiple main functions found in package 'main'
#   Found 2 main functions:
#     - main.ha:2:1 - function main()
#     - secondary.ha:2:1 - function main()
```

### Multi-Package Examples
```bash
# Each package can be run independently:
harneet examples/main_function_validation/multi_package/main/
harneet examples/main_function_validation/multi_package/cmd/
```

## Linter Integration

Run the linter to detect main function violations early:

```bash
harneet-lint examples/main_function_validation/invalid_patterns/
```

This will show warnings before compilation, helping you catch issues during development.