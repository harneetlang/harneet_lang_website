def nested_loop_calculation():
    result = 0
    for i in range(100):
        for j in range(100):
            for k in range(10):
                result += i * j * k
    return result

def matrix_multiplication():
    size = 50
    
    # Initialize matrices
    a = [[i + j for j in range(size)] for i in range(size)]
    b = [[i * j + 1 for j in range(size)] for i in range(size)]
    
    # Matrix multiplication
    result = 0
    for i in range(size):
        for j in range(size):
            total = sum(a[i][k] * b[k][j] for k in range(size))
            result += total
    
    return result

if __name__ == "__main__":
    nested_result = nested_loop_calculation()
    matrix_result = matrix_multiplication()
    
    print(f"Nested loops: {nested_result}, Matrix multiplication: {matrix_result}")