if __name__ == "__main__":
    s = ""
    for i in range(1000):
        s = s + "a"
    print(len(s))
