#!/bin/bash

echo "Timing Harneet String Manipulation..."
{ time ./harneet examples/performance/string_manipulation.ha; } 2>&1

echo ""

echo "Timing Python String Manipulation..."
{ time python3 examples/performance/string_manipulation.py; } 2>&1

echo "==============================================="

