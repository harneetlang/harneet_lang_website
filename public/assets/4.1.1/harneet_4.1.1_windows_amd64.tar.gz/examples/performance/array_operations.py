def array_sum(arr):
    return sum(arr)

def array_reverse(arr):
    return arr[::-1]

def bubble_sort(arr):
    arr = arr.copy()  # Don't modify original
    n = len(arr)
    for i in range(n - 1):
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

if __name__ == "__main__":
    # Create large array
    arr = list(range(1000, 0, -1))
    
    # Test sum operation
    total = array_sum(arr)
    
    # Test reverse operation
    reversed_arr = array_reverse(arr)
    
    # Test sorting operation
    sorted_arr = bubble_sort(arr)
    
    print(f"Sum: {total}, First reversed: {reversed_arr[0]}, First sorted: {sorted_arr[0]}")