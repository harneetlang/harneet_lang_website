#!/usr/bin/env python3

def main():
    s = ""
    for i in range(1000):
        s = s + "a"
    length = len(s)
    print(length)

if __name__ == "__main__":
    main()
