def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

def iterative_factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

if __name__ == "__main__":
    # Test recursive factorial
    recursive_result = factorial(15)
    
    # Test iterative factorial
    iterative_result = iterative_factorial(15)
    
    # Multiple calculations to stress test
    total = sum(factorial(i) for i in range(1, 13))
    
    print(f"Recursive: {recursive_result}, Iterative: {iterative_result}, Sum: {total}")