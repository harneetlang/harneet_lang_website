#!/usr/bin/env python3

def fib(n):
    if n <= 1:
        return n
    return fib(n - 1) + fib(n - 2)

def main():
    result = fib(20)
    print(result)

if __name__ == "__main__":
    main()
