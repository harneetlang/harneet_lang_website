# Multi-Package Project Example

This example demonstrates how different packages can each have their own main function without conflict.

## Package Structure

```
multi_package/
├── main/           # Main application package
│   ├── main.ha     # Main application entry point (has main function)
│   └── config.ha   # Configuration helpers (no main function)
├── cmd/            # CLI tool package  
│   ├── cli.ha      # CLI tool entry point (has main function)
│   └── flags.ha    # CLI flag helpers (no main function)
└── utils/          # Shared utility package
    ├── common.ha   # Common utilities (no main function)
    └── helpers.ha  # Additional helpers (no main function)
```

## Key Points

1. **Package Isolation**: Each package is validated independently
   - `main` package has one main function ✓
   - `cmd` package has one main function ✓  
   - `utils` package has no main function ✓ (valid for libraries)

2. **No Conflicts**: The main functions in different packages don't conflict with each other

3. **Clear Separation**: Each package serves a different purpose:
   - `main`: Core application logic
   - `cmd`: Command-line interface
   - `utils`: Shared utilities

## Running the Examples

Each package with a main function can be run independently:

```bash
# Run the main application
harneet examples/main_function_validation/multi_package/main/

# Run the CLI tool
harneet examples/main_function_validation/multi_package/cmd/

# The utils package cannot be run directly (no main function)
# It would be imported by other packages instead
```

## Expected Output

**Main application:**
```
=== Main Application ===
This is the main application entry point
Package: main
Initializing main application...
Running main application logic...
Main application completed
```

**CLI tool:**
```
=== CLI Tool ===
This is the CLI tool entry point
Package: cmd
Parsing command line arguments...
Executing CLI commands...
CLI tool completed
```