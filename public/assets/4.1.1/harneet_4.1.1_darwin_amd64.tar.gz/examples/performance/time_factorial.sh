#!/bin/bash

echo "Timing Harneet Factorial Operations..."
{ time ./harneet examples/performance/recursive_factorial.ha; } 2>&1

echo ""

echo "Timing Python Factorial Operations..."
{ time python3 examples/performance/recursive_factorial.py; } 2>&1

echo "==============================================="