#!/bin/bash

echo "Timing Harneet Nested Loops & Matrix Operations..."
{ time ./harneet examples/performance/nested_loops.ha; } 2>&1

echo ""

echo "Timing Python Nested Loops & Matrix Operations..."
{ time python3 examples/performance/nested_loops.py; } 2>&1

echo "==============================================="