#!/usr/bin/env python3

def array_sum(arr):
    total = 0
    for i in arr:
        total = total + i
    return total

def main():
    # Create array with 100 elements (matching the Harneet version)
    arr = list(range(1000, 900, -1))
    
    # Test sum operation multiple times for performance
    sum1 = array_sum(arr)
    sum2 = array_sum(arr)
    sum3 = array_sum(arr)
    sum4 = array_sum(arr)
    sum5 = array_sum(arr)
    
    # Test array length
    length = len(arr)
    
    print(f"Sum: {sum1}, Length: {length}")

if __name__ == "__main__":
    main()
